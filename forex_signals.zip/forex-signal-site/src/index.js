import React from "react";
import ReactDOM from "react-dom/client";
import ForexSignals from "./App";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <ForexSignals />
  </React.StrictMode>
);